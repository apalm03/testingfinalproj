create definer = root@localhost trigger cus_trigger
    after INSERT
    on customer
    for each row
BEGIN
insert into ccustomer_history(customer.id,customer_name,customer_street,customer_city) values
(new.customer_id,new.customer_name,new.customer_street,new.customer_city);

END;

