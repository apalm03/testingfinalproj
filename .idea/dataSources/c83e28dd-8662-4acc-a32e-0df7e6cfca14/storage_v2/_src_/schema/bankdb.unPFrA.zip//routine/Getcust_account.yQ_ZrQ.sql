create
    definer = root@localhost procedure Getcust_account(IN cust_name varchar(50))
BEGIN
 select account_number from depositor join customer on customer.customer_id = depositor.customer_id where access_date between '2001/01/01' and '2006/12/31' and customer_name= cust_name;
END;

